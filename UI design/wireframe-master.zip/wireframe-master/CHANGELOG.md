Change Log
==========


0.2.0 (2014-12-12)
------------------

- Only use 1 Helvetica Font in the file.
- Reorganize Symbols.
- Edit some inconsistent element.
- Fix some typos in Symbol name.

0.1.0 (2014-12-05)
------------------

The first milestone release
