Release Process
===============

img
---

update images from `img` directory to make sure they are updated (with the right version)


CHANGLOG
--------

update CHANGELOG for the release version


README
------

Update the right paths of images to the target released version.

For example:

https://raw.githubusercontent.com/teracyhq/wireframe/develop/img/symbols.png

to

https://raw.githubusercontent.com/teracyhq/wireframe/v0.2.0/img/symbols.png
